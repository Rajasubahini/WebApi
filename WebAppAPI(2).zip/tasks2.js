function UpdateNews(id)
{
    // Requests a quote to the quote.rest API, specifying the category (function's argument).
    // If the request was successful, the quote and author are displayed in the div element specified
    // in the argument of the function.
    // Errors are handled both if the request was successful or not.
    $.ajax({
        url: "https://hacker-news.firebaseio.com/v0/item/" + id + ".json",
        type: "GET",
        success: function(result){ 
            if(result.hasOwnProperty('failure'))
            {
                alert("Error: " + result.reason);
            }
            else
            {
                // create html objects
                var by = $("<p></p>").text("Story By - " + result.by);
				var title = $("<b><p></p></b>").text("Title - " + result.title);
				var type = $("<p></p>").text("Type - " + result.type);
				var score = $("<p></p><br/>").text("Score - " + result.score);
				var qod = $("<div></div>").append(title, by, type, score);
							
				var myStringArray = result.kids;
				var arrayLength = myStringArray.length;
				
				
				
				for (var i = 0; i < arrayLength; i++) 
				{
					//window.alert(myStringArray[i]);
					
					$.ajax({
							url: "https://hacker-news.firebaseio.com/v0/item/" + myStringArray[i] + ".json",
							type: "GET",
							success: function(result2){ 
								if(result.hasOwnProperty('failure'))
								{
									alert("Error: " + result2.reason);
								}
								else
								{
									// create html objects
									var commentBy = $("<p></p>").text("Comment By - " + result2.by);
									var commentText = $("<p></p>").text("Type - " + result2.text);
									var qod = $("<div></div></br>").append(commentBy, commentText);
									
									// append to div
									//$("#" + id).empty();
									$(div_comment_t1).append(qod);
								} 
							},
							error: function(e) {
								response = JSON.parse(e.responseText); 
								alert("Couldn't get the quote of the day!\n\nError " + response.error.code + "\n" + response.error.message);
							}
						});
				}
                
                // append to div
                //$("#" + id).empty();
                $(div_quote_t1).append(qod);
            } 
        },
        error: function(e) {
            response = JSON.parse(e.responseText); 
            alert("Couldn't get the quote of the day!\n\nError " + response.error.code + "\n" + response.error.message);
        }
    });
}


//// TASKS IMPLEMENTATION

$(document).ready(function(){
	
	var url = window.location.search;
	url = url.replace("?", ''); // remove the ?
	//alert(url);

    UpdateNews(url);

});
