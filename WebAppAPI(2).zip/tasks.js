function UpdateNewPage(id)
{
	//window.alert(id);
	window.open("index2.html?" + id)
}

//Function for New Stories
function UpdateNewStory(id)
{
    // Requests a quote to the quote.rest API, specifying the category (function's argument).
    // If the request was successful, the quote and author are displayed in the div element specified
    // in the argument of the function.
    // Errors are handled both if the request was successful or not.
	$.ajax({
			url: "https://hacker-news.firebaseio.com/v0/newstories.json",
			type: "GET",
			success: function(result){ 
				if(result.hasOwnProperty('failure'))
				{
					alert("Error: " + result.reason);
				}
				else
				{
						var myStringArray = result;
						var arrayLength = myStringArray.length;
						$("#" + id).empty();
						for (var i = 0; i < 50; i++) 
						{
						
							$.ajax({
								url: "https://hacker-news.firebaseio.com/v0/item/" + myStringArray[i] + ".json",
								type: "GET",
								success: function(result){ 
									if(result.hasOwnProperty('failure'))
									{
										alert("Error: " + result.reason);
									}
									else
									{
										// create html objects
										var by = $("<p></p>").text("Story By - " + result.by);
										var title = $("<a href='#' onclick=UpdateNewPage(" + result.id + ")><b><p></p></b></a>").text("Title - " + result.title);
										var type = $("<p></p>").text("Type - " + result.type);
										var score = $("<p></p><br/>").text("Score - " + result.score);
										var qod = $("<div></div>").append(title, by, type, score);
										
										// append to div
										$("#" + id).append(qod);
									} 
								},
								error: function(e) {
									response = JSON.parse(e.responseText); 
									alert("Couldn't get the quote of the day!\n\nError " + response.error.code + "\n" + response.error.message);
								}
							});
						}
				} 
			},
			error: function(e) {
				response = JSON.parse(e.responseText); 
				alert("Couldn't get the quote of the day!\n\nError " + response.error.code + "\n" + response.error.message);
			}
		});
	
	
	
}

//Function for Best Stories
function UpdateTopStory(id)
{
    // Requests a quote to the quote.rest API, specifying the category (function's argument).
    // If the request was successful, the quote and author are displayed in the div element specified
    // in the argument of the function.
    // Errors are handled both if the request was successful or not.
	$.ajax({
			url: "https://hacker-news.firebaseio.com/v0/topstories.json",
			type: "GET",
			success: function(result){ 
				if(result.hasOwnProperty('failure'))
				{
					alert("Error: " + result.reason);
				}
				else
				{
						var myStringArray = result;
						var arrayLength = myStringArray.length;
						$("#" + id).empty();
						for (var i = 0; i < arrayLength; i++) 
						{
						
							$.ajax({
								url: "https://hacker-news.firebaseio.com/v0/item/" + myStringArray[i] + ".json",
								type: "GET",
								success: function(result){ 
									if(result.hasOwnProperty('failure'))
									{
										alert("Error: " + result.reason);
									}
									else
									{
										// create html objects
										var by = $("<p></p>").text("Story By - " + result.by);
										var title = $("<a href='#' onclick=UpdateNewPage(" + result.id + ")><b><p></p></b></a>").text("Title - " + result.title);
										var type = $("<p></p>").text("Type - " + result.type);
										var score = $("<p></p><br/>").text("Score - " + result.score);
										var qod = $("<div></div>").append(title, by, type, score);
										
										// append to div
										//$("#" + id).empty();
										$("#" + id).append(qod);
									} 
								},
								error: function(e) {
									response = JSON.parse(e.responseText); 
									alert("Couldn't get the quote of the day!\n\nError " + response.error.code + "\n" + response.error.message);
								}
							});
						}
				} 
			},
			error: function(e) {
				response = JSON.parse(e.responseText); 
				alert("Couldn't get the quote of the day!\n\nError " + response.error.code + "\n" + response.error.message);
			}
		});
	
	
	
}

//Function for Top Stories
function UpdateBestStory(id)
{
    // Requests a quote to the quote.rest API, specifying the category (function's argument).
    // If the request was successful, the quote and author are displayed in the div element specified
    // in the argument of the function.
    // Errors are handled both if the request was successful or not.
	$.ajax({
			url: "https://hacker-news.firebaseio.com/v0/beststories.json",
			type: "GET",
			success: function(result){ 
				if(result.hasOwnProperty('failure'))
				{
					alert("Error: " + result.reason);
				}
				else
				{
						var myStringArray = result;
						var arrayLength = myStringArray.length;
						$("#" + id).empty();
						for (var i = 0; i < arrayLength; i++) 
						{
						
							$.ajax({
								url: "https://hacker-news.firebaseio.com/v0/item/" + myStringArray[i] + ".json",
								type: "GET",
								success: function(result){ 
									if(result.hasOwnProperty('failure'))
									{
										alert("Error: " + result.reason);
									}
									else
									{
										// create html objects
										var by = $("<p></p>").text("Story By - " + result.by);
										var title = $("<a href='#' onclick=UpdateNewPage(" + result.id + ")><b><p></p></b></a>").text("Title - " + result.title);
										var type = $("<p></p>").text("Type - " + result.type);
										var score = $("<p></p><br/>").text("Score - " + result.score);
										var qod = $("<div></div>").append(title, by, type, score);
										
										// append to div
										//$("#" + id).empty();
										$("#" + id).append(qod);
									} 
								},
								error: function(e) {
									response = JSON.parse(e.responseText); 
									alert("Couldn't get the quote of the day!\n\nError " + response.error.code + "\n" + response.error.message);
								}
							});
						}
				} 
			},
			error: function(e) {
				response = JSON.parse(e.responseText); 
				alert("Couldn't get the quote of the day!\n\nError " + response.error.code + "\n" + response.error.message);
			}
		});
	
	
	
}



//// TASKS IMPLEMENTATION

$(document).ready(function(){

    // Task 1
    $("#btn_t1").click(function(){
        UpdateNewStory("div_quote_t1");
    });
	
	$("#btn_t2").click(function(){
        UpdateTopStory("div_quote_t1");
    });
	
	$("#btn_t3").click(function(){
        UpdateBestStory("div_quote_t1");
    });

});
